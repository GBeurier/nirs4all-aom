# Operator-Adaptive PLS - arXiv submission package

Build instructions:

    pdflatex main
    bibtex   main
    pdflatex main
    pdflatex main

Files:

- main.tex / references.bib: manuscript and bibliography.
- supplement/supplement.tex: supplementary material.
- figures/*.pdf: precompiled figures (regenerate with
  `bench/AOM_v0/publication/scripts/make_figures.py`).
- tables/*.tex: tables included via \input.

This archive contains no shell escapes and no external paths; pdflatex
should run without -shell-escape.
